class DirectedGraph:
    def __init__(self, V: int):
        self.V: int = V
        self.adj: list[list[int]] = [[] for _ in range(V)]

    def add_edge(self, v1, v2):
        self.adj[v1].append(v2)
        